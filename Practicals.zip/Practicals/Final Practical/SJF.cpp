#include <iostream>
using namespace std;

int main() {
    int A[100][4]; // Process array: A[][0] = process ID, A[][1] = Burst Time, A[][2] = Waiting Time, A[][3] = Turnaround Time
    int i, j, n, total = 0, index, temp;
    float avg_wt, avg_tat;

    cout << "Enter number of processes: ";
    cin >> n;

    // Input Burst Times
    cout << "Enter Burst Time for each process:" << endl;
    for (i = 0; i < n; i++) {
        cout << "P" << i + 1 << ": ";
        cin >> A[i][1];  // Burst time
        A[i][0] = i + 1; // Process ID
    }

    // Sorting the processes based on Burst Time (SJF)
    for (i = 0; i < n; i++) {
        index = i;
        for (j = i + 1; j < n; j++) {
            if (A[j][1] < A[index][1]) {  // Find the process with the shortest burst time
                index = j;
            }
        }
        // Swap process details (ID and Burst Time)
        temp = A[i][1];
        A[i][1] = A[index][1];
        A[index][1] = temp;

        temp = A[i][0];
        A[i][0] = A[index][0];
        A[index][0] = temp;
    }

    // Calculating Waiting Time for each process
    A[0][2] = 0; // First process has zero waiting time
    for (i = 1; i < n; i++) {
        A[i][2] = 0;
        for (j = 0; j < i; j++) {
            A[i][2] += A[j][1];
        }
        total += A[i][2];
    }
    avg_wt = (float)total / n; // Average Waiting Time

    // Reset total for Turnaround Time calculation
    total = 0;
    cout << "\nProcess\tBurst Time\tWaiting Time\tTurnaround Time" << endl;

    // Calculating Turnaround Time and displaying the results
    for (i = 0; i < n; i++) {
        A[i][3] = A[i][1] + A[i][2]; // Turnaround Time = Burst Time + Waiting Time
        total += A[i][3];
        cout << "P" << A[i][0] << "\t\t" << A[i][1] << "\t\t" << A[i][2] << "\t\t" << A[i][3] << endl;
    }
    avg_tat = (float)total / n; // Average Turnaround Time

    // Displaying average WT and TAT
    cout << "\nAverage Waiting Time: " << avg_wt << endl;
    cout << "Average Turnaround Time: " << avg_tat << endl;

    return 0;
}

